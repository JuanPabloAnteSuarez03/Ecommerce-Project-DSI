module.exports = {
  singleQuote: true,
  tailwindConfig: './tailwind.config.js',
};
