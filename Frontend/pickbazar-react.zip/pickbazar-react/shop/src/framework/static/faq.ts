export const faq = [
  {
    title: 'faq-one-title',
    content: 'faq-one-content',
  },
  {
    title: 'faq-two-title',
    content: 'faq-two-content',
  },
  {
    title: 'faq-three-title',
    content: 'faq-three-content',
  },
  {
    title: 'faq-four-title',
    content: 'faq-four-content',
  },
];
